﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using static System.Reflection.Metadata.BlobBuilder;

using University_Managment_System;

    public class BookLoans
    {
        public int Id { get; set; } // Primary Key

        [Required]
        public int StudentId { get; set; } // Foreign Key

        [Required]
        public DateTime LoanDate { get; set; } // Date when the book was loaned

        public DateTime? ReturnDate { get; set; } // Date when the book was returned (nullable)

        [ForeignKey("StudentId")]
        public Student Student { get; set; }

        [Required]
        public int BookId { get; set; } // Foreign Key

        [ForeignKey("BookId")]
        public Books Book { get; set; } // Navigation property to Book
    }

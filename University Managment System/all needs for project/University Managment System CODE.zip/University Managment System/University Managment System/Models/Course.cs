﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

using University_Managment_System;
using University_Managment_System;

public class Course
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; } // Name

        [Required]
        public int Credits { get; set; }

        [Required]
        public int DepartmentId { get; set; }

        [ForeignKey("DepartmentId")]
        public Department Department { get; set; }

        [Required]
        public int SemesterId { get; set; }

        [ForeignKey("SemesterId")]
        public Semester Semester { get; set; }

        public ICollection<EnrollStudentInCourse> EnrollStudentInCourses { get; set; } = [];
        public ICollection<AcademicRecord> AcademicRecords { get; set; } = [];
        public ICollection<TeachingAssistant> TeachingAssistants { get; set; } = [];
        public ICollection<FinalGrade> FinalResults { get; set; } = [];
        public ICollection<AcademicGrade> AcademicGrades { get; set; } = [];
        public ICollection<Professor> Professors { get; set; } = [];
    public ICollection<Administrator> Administrators { get; set; } = new List<Administrator>();
}

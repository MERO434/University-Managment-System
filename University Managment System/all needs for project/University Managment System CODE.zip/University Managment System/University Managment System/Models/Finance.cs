﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

using University_Managment_System;

public class Finance
    {
        public int Id { get; set; } // Primary Key

        [Required]
        public int StudentId { get; set; } // Foreign Key to Student

        [ForeignKey("StudentId")]
        public Student Student { get; set; } // Navigation property to Student

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal AmountDue { get; set; } // Amount due

        [Required]
        public int SemesterId { get; set; }

        [ForeignKey("SemesterId")]
        public Semester Semester { get; set; }

        public bool IsPaid { get; set; } // Payment status
    }
